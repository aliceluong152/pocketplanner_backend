package fdm.group.com.SpringPocketPlanner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

import fdm.group.com.SpringPocketPlanner.dal.BudgetRespository;
import fdm.group.com.SpringPocketPlanner.dal.ExpenseRespository;
import fdm.group.com.SpringPocketPlanner.dal.UserRespository;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.model.Expense;
import fdm.group.com.SpringPocketPlanner.service.BudgetService;
import fdm.group.com.SpringPocketPlanner.service.ExpenseService;
import fdm.group.com.SpringPocketPlanner.service.UserService;
import jakarta.transaction.Transactional;
@Service
public class Runner implements ApplicationRunner{
	UserRespository userRepo;
	UserService userService;
	BudgetRespository budgetRepo;
	BudgetService budgetService;
	ExpenseRespository expenseRepo;
	ExpenseService expenseService;

	@Autowired
	public Runner(UserRespository userRepo, UserService userService, BudgetRespository budgetRepo,
			BudgetService budgetService, ExpenseRespository expenseRepo,ExpenseService expenseService) {
		super();
		this.userRepo = userRepo;
		this.userService = userService;
		this.budgetRepo = budgetRepo;
		this.budgetService = budgetService;
		this.expenseRepo = expenseRepo;
		this.expenseService = expenseService;
	}

	@Override
	@Transactional
	public void run(ApplicationArguments args) throws Exception {
		//1. Persist users
		ArrayList<User>users = new ArrayList<>();
		
		User user = new User("johndoe01", "john.doe01@example.com", "securePass1!", "123-456-7890");
		users.add(user);
		User user2 = new User("janedoe01", "jane.doe01@example.com", "uniquePass2@", "123-456-7891");
		users.add(user2);
		User user3 = new User("samsam01", "sam.sam01@example.com", "myPassword3#", "123-456-7892");
		users.add(user3);
		User user4 = new User("lilyflower01", "lily.flower01@example.com", "flowerPass4$", "123-456-7893");
		users.add(user4);
		User user5 = new User("jackblack01", "jack.black01@example.com", "blackJack5%", "123-456-7894");
		users.add(user5);
		User user6 = new User("annasmith01", "anna.smith01@example.com", "smithAnna6^", "123-456-7895");
		users.add(user6);
		User user7 = new User("bobbyray01", "bobby.ray01@example.com", "bobbyR7&", "123-456-7896");
		users.add(user7);
		User user8 = new User("chloegreen01", "chloe.green01@example.com", "greenC8*", "123-456-7897");
		users.add(user8);
		User user9 = new User("davewhite01", "dave.white01@example.com", "whiteD9(", "123-456-7898");
		users.add(user9);
		User user10 = new User("ellenpage01", "ellen.page01@example.com", "pageE10)", "123-456-7899");
		users.add(user10);
		User user11 = new User("frankmiller01", "frank.miller01@example.com", "millerF11_", "123-456-7900");
		users.add(user11);
		User user12 = new User("gracehall01", "grace.hall01@example.com", "hallG12+", "123-456-7901");
		users.add(user12);
		User user13 = new User("harrypotter01", "harry.potter01@example.com", "potterH13=", "123-456-7902");
		users.add(user13);
		User user14 = new User("irenewood01", "irene.wood01@example.com", "woodI14-", "123-456-7903");
		users.add(user14);
		User user15 = new User("jakestorm01", "jake.storm01@example.com", "stormJ15{", "123-456-7904");
		users.add(user15);
		User user16 = new User("kellywise01", "kelly.wise01@example.com", "wiseK16}", "123-456-7905");
		users.add(user16);
		User user17 = new User("lucasperry01", "lucas.perry01@example.com", "perryL17[", "123-456-7906");
		users.add(user17);
		User user18 = new User("mollycarter01", "molly.carter01@example.com", "carterM18]", "123-456-7907");
		users.add(user18);
		User user19 = new User("nancygrey01", "nancy.grey01@example.com", "greyN19|", "123-456-7908");
		users.add(user19);
		User user20 = new User("oscarmiles01", "oscar.miles01@example.com", "milesO20~", "123-456-7909");
		users.add(user20);
		User user21 = new User("patriciastar01", "patricia.star01@example.com", "starP21^", "123-456-7910");
		users.add(user21);
		User user22 = new User("quinnray01", "quinn.ray01@example.com", "rayQ22@", "123-456-7911");
		users.add(user22);
		User user23 = new User("robertfox01", "robert.fox01@example.com", "foxR23#", "123-456-7912");
		users.add(user23);
		User user24 = new User("sophiawhite01", "sophia.white01@example.com", "whiteS24$", "123-456-7913");
		users.add(user24);
		User user25 = new User("tommylee01", "tommy.lee01@example.com", "leeT25%", "123-456-7914");
		users.add(user25);
		User user26 = new User("ursulaking01", "ursula.king01@example.com", "kingU26^", "123-456-7915");
		users.add(user26);
		User user27 = new User("victorzane01", "victor.zane01@example.com", "zaneV27&", "123-456-7916");
		users.add(user27);
		User user28 = new User("wendyblue01", "wendy.blue01@example.com", "blueW28*", "123-456-7917");
		users.add(user28);
		User user29 = new User("xavierhill01", "xavier.hill01@example.com", "hillX29(", "123-456-7918");
		users.add(user29);
		User user30 = new User("yolandapark01", "yolanda.park01@example.com", "parkY30)", "123-456-7919");
		users.add(user30);
		
//		userRepo.saveAll(users);
		userService.saveAll(users);
		
		//2.persist budget data
		
		ArrayList<Budget>budgets = new ArrayList<>();
		
		Budget budget = new Budget(user, "Groceries", 250.00, "January");
		Budget budget1 = new Budget(user, "Utilities", 75.00, "January");
		Budget budget2 = new Budget(user, "Transportation", 150.00, "January");
		budgets.add(budget);
		budgets.add(budget1);
		budgets.add(budget2);
		
//        //  User 2
		Budget budget3 = new Budget(user2, "Healthcare", 200.00, "January");
		Budget budget4 = new Budget(user2, "Entertainment", 100.00, "January");
		Budget budget5 = new Budget(user2, "Education", 300.00, "January");
		budgets.add(budget3);
		budgets.add(budget4);
		budgets.add(budget5);
        // user 3
		Budget budget6 = new Budget(user3, "Clothing", 100.00, "February");
		Budget budget7 = new Budget(user3, "Gifts", 50.00, "February");
		Budget budget8 = new Budget(user3, "Fitness", 75.00, "February");
		budgets.add(budget6);
		budgets.add(budget7);
		budgets.add(budget8);

		Budget budget9 = new Budget(user4, "Travel", 500.00, "February");
		Budget budget10 = new Budget(user4, "Groceries", 250.00, "February");
		Budget budget11 = new Budget(user4, "Utilities", 130.00, "February");
		budgets.add(budget9);
		budgets.add(budget10);
		budgets.add(budget11);

		Budget budget12 = new Budget(user5, "Transportation", 120.00, "March");
		Budget budget13 = new Budget(user5, "Healthcare", 300.00, "March");
		Budget budget14 = new Budget(user5, "Entertainment", 180.00, "March");
		budgets.add(budget12);
		budgets.add(budget13);
		budgets.add(budget14);
		Budget budget15 = new Budget(user6, "Education", 350.00, "March");
		Budget budget16 = new Budget(user6, "Clothing", 220.00, "March");
		Budget budget17 = new Budget(user6, "Gifts", 100.00, "March");
		budgets.add(budget15);
		budgets.add(budget16);
		budgets.add(budget17);
		Budget budget18 = new Budget(user7, "Vacation", 1200.00, "April");
		Budget budget19 = new Budget(user7, "Books", 85.00, "April");
		Budget budget20 = new Budget(user7, "Dining", 250.00, "April");
		budgets.add(budget18);
		budgets.add(budget19);
		budgets.add(budget20);
        // For User 8
		Budget budget21 = new Budget(user8, "Groceries", 310.00, "May");
		Budget budget22 = new Budget(user8, "Utilities", 140.00, "May");
		Budget budget23 = new Budget(user8, "Health & Wellness", 200.00, "May");
		budgets.add(budget20);
		budgets.add(budget21);
		budgets.add(budget22);
        // For User 9
		Budget budget24 = new Budget(user9, "Entertainment", 150.00, "June");
		Budget budget25 = new Budget(user9, "Education", 450.00, "June");
		Budget budget26 = new Budget(user9, "Clothing", 220.00, "June");
		budgets.add(budget24);
		budgets.add(budget25);
		budgets.add(budget26);
        // For User 10
		Budget budget27 = new Budget(user10, "Travel", 500.00, "July");
		Budget budget28 = new Budget(user10, "Pet Care", 100.00, "July");
		Budget budget29 = new Budget(user10, "Gym", 50.00, "July");
		budgets.add(budget27);
		budgets.add(budget28);
		budgets.add(budget29);
        // For User 11
		Budget budget30 = new Budget(user11, "Transportation", 180.00, "November");
		Budget budget31 = new Budget(user11, "Home Repair", 200.00, "November");
		Budget budget32 = new Budget(user11, "Charity", 150.00, "November");
		budgets.add(budget30);
		budgets.add(budget31);
		budgets.add(budget32);
        // For User 12
		Budget budget33 = new Budget(user12, "Groceries", 220.00, "December");
		Budget budget34 = new Budget(user12, "Gifts", 300.00, "December");
		Budget budget35 = new Budget(user12, "Fitness", 90.00, "December");
		budgets.add(budget33);
		budgets.add(budget34);
		budgets.add(budget35);
        // For User 13
		Budget budget36 = new Budget(user13, "Utilities", 160.00, "January");
		Budget budget37 = new Budget(user13, "Healthcare", 230.00, "January");
		Budget budget38 = new Budget(user13, "Vacation", 1100.00, "January");
		budgets.add(budget36);
		budgets.add(budget37);
		budgets.add(budget38);
        // For User 14
		Budget budget39 = new Budget(user14, "Education", 450.00, "February");
		Budget budget40 = new Budget(user14, "Dining Out", 250.00, "February");
		Budget budget41 = new Budget(user14, "Pets", 180.00, "February");
		budgets.add(budget39);
		budgets.add(budget40);
		budgets.add(budget41);
        // For User 15
		Budget budget42 = new Budget(user15, "Entertainment", 200.00, "March");
		Budget budget43 = new Budget(user15, "Clothing", 300.00, "March");
		Budget budget44 = new Budget(user15, "Electronics", 500.00, "March");
		budgets.add(budget42);
		budgets.add(budget43);
		budgets.add(budget44);
        // For User 16
		Budget budget45 = new Budget(user16, "Gardening", 120.00, "April");
		Budget budget46 = new Budget(user16, "Books", 80.00, "April");
		Budget budget47 = new Budget(user16, "Travel", 400.00, "April");
		budgets.add(budget45);
		budgets.add(budget46);
		budgets.add(budget47);
        // For User 17
		Budget budget48 = new Budget(user17, "Groceries", 310.00, "May");
		Budget budget49 = new Budget(user17, "Utilities", 140.00, "May");
		Budget budget50 = new Budget(user17, "Health & Wellness", 200.00, "May");
		budgets.add(budget48);
		budgets.add(budget49);
		budgets.add(budget50);
        // For User 18
		Budget budget51 = new Budget(user18, "Entertainment", 150.00, "June");
		Budget budget52 = new Budget(user18, "Education", 450.00, "June");
		Budget budget53 = new Budget(user18, "Clothing", 220.00, "June");
		budgets.add(budget51);
		budgets.add(budget52);
		budgets.add(budget53);
        // For User 19
		Budget budget54 = new Budget(user19, "Travel", 500.00, "July");
		Budget budget55 = new Budget(user19, "Pet Care", 100.00, "July");
		Budget budget56 = new Budget(user19, "Gym", 50.00, "July");
		budgets.add(budget54);
		budgets.add(budget55);
		budgets.add(budget56);
        // For User 20
		Budget budget57 = new Budget(user20, "Transportation", 180.00, "August");
		Budget budget58 = new Budget(user20, "Home Repair", 200.00, "August");
		Budget budget59 = new Budget(user20, "Charity", 150.00, "August");
		budgets.add(budget57);
		budgets.add(budget58);
		budgets.add(budget59);
     // For User 21
		Budget budget60 = new Budget(user21, "Groceries", 220.00, "September");
		Budget budget61 = new Budget(user21, "Gifts", 300.00, "September");
		Budget budget62 = new Budget(user21, "Fitness", 90.00, "September");
		budgets.add(budget60);
		budgets.add(budget61);
		budgets.add(budget62);
        // For User 22
		Budget budget63 = new Budget(user22, "Utilities", 160.00, "October");
		Budget budget64 = new Budget(user22, "Healthcare", 230.00, "October");
		Budget budget65 = new Budget(user22, "Vacation", 1100.00, "October");
		budgets.add(budget63);
		budgets.add(budget64);
		budgets.add(budget65);
        // For User 23
		Budget budget66 = new Budget(user23, "Education", 450.00, "November");
		Budget budget67 = new Budget(user23, "Dining Out", 250.00, "November");
		Budget budget68 = new Budget(user23, "Pets", 180.00, "November");
		budgets.add(budget66);
		budgets.add(budget67);
		budgets.add(budget68);
        // For User 24
		Budget budget69 = new Budget(user24, "Entertainment", 200.00, "December");
		Budget budget70 = new Budget(user24, "Clothing", 300.00, "December");
		Budget budget71 = new Budget(user24, "Electronics", 500.00, "December");
		budgets.add(budget69);
		budgets.add(budget70);
		budgets.add(budget71);
        // For User 25
		Budget budget72 = new Budget(user25, "Gardening", 120.00, "January");
		Budget budget73 = new Budget(user25, "Books", 80.00, "January");
		Budget budget74 = new Budget(user25, "Travel", 400.00, "January");
		budgets.add(budget72);
		budgets.add(budget73);
		budgets.add(budget74);
        // For User 26
		Budget budget75 = new Budget(user26, "Groceries", 310.00, "February");
		Budget budget76 = new Budget(user26, "Utilities", 140.00, "February");
		Budget budget77 = new Budget(user26, "Health & Wellness", 200.00, "February");
		budgets.add(budget75);
		budgets.add(budget76);
		budgets.add(budget77);
        // For User 27
		Budget budget78 = new Budget(user27, "Entertainment", 150.00, "March");
		Budget budget79 = new Budget(user27, "Education", 450.00, "March");
		Budget budget80 = new Budget(user27, "Clothing", 220.00, "March");
		budgets.add(budget78);
		budgets.add(budget79);
		budgets.add(budget80);
        // For User 28
		Budget budget81 = new Budget(user28, "Travel", 500.00, "April");
		Budget budget82 = new Budget(user28, "Pet Care", 100.00, "April");
		Budget budget83 = new Budget(user28, "Gym", 50.00, "April");
		budgets.add(budget81);
		budgets.add(budget82);
		budgets.add(budget83);
        // For User 29
		Budget budget84 = new Budget(user29, "Transportation", 180.00, "May");
		Budget budget85 = new Budget(user29, "Home Repair", 200.00, "May");
		Budget budget86 = new Budget(user29, "Charity", 150.00, "May");
		budgets.add(budget84);
		budgets.add(budget85);
		budgets.add(budget86);
        // For User 30
		Budget budget87 = new Budget(user30, "Groceries", 220.00, "June");
		Budget budget88 = new Budget(user30, "Gifts", 300.00, "June");
		Budget budget89 = new Budget(user30, "Fitness", 90.00, "June");
		budgets.add(budget87);
		budgets.add(budget88);
		budgets.add(budget89);
		
		budgetRepo.saveAll(budgets);
		
		//3.persist expense data
		ArrayList<Expense>expenses = new ArrayList<>();
		
		Expense expense = new Expense (user, "Groceries", 50.00, parseDate("2024-04-01"));
        Expense expense1 = new Expense (user, "Utilities", 30.00, parseDate("2024-04-02"));
        Expense expense2 = new Expense (user, "Transportation", 20.00, parseDate("2024-04-03"));
        expenses.add(expense);
        expenses.add(expense1);
        expenses.add(expense2);
        Expense expense3 = new Expense(user2, "Groceries", 40.00, parseDate("2024-04-01"));
        Expense expense4 = new Expense(user2, "Entertainment", 25.00, parseDate("2024-04-02"));
        Expense expense5 = new Expense(user2, "Utilities", 50.00, parseDate("2024-04-03"));
        expenses.add(expense3);
        expenses.add(expense4);
        expenses.add(expense5);
     // User 3 expenses
        Expense expense6 = new Expense(user3, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense7 = new Expense(user3, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense8 = new Expense(user3, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense6);
        expenses.add(expense7);
        expenses.add(expense8);
        // User 4 expenses
        Expense expense9 = new Expense(user4, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense10 = new Expense(user4, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense11 = new Expense(user4, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense9);
        expenses.add(expense10);
        expenses.add(expense11);
     // User 5 expenses
        Expense expense12 = new Expense(user5, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense13 = new Expense(user5, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense14 = new Expense(user5, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense12);
        expenses.add(expense13);
        expenses.add(expense14);
        // User 6 expenses
        Expense expense15 = new Expense(user6, "Entertainment", 40.00, parseDate("2024-04-01"));
        Expense expense16 = new Expense(user6, "Utilities", 35.00, parseDate("2024-04-02"));
        Expense expense17 = new Expense(user6, "Healthcare", 50.00, parseDate("2024-04-03"));
        expenses.add(expense15);
        expenses.add(expense16);
        expenses.add(expense17);
     // User 7 expenses
        Expense expense18 = new Expense(user7, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense19 = new Expense(user7, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense20 = new Expense(user7, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense18);
        expenses.add(expense19);
        expenses.add(expense20);
        // User 8 expenses
        Expense expense21 = new Expense(user8, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense22 = new Expense(user8, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense23 = new Expense(user8, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense21);
        expenses.add(expense22);
        expenses.add(expense23);
        // User 9 expenses
        Expense expense24 = new Expense(user9, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense25 = new Expense(user9, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense26 = new Expense(user9, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense24);
        expenses.add(expense25);
        expenses.add(expense26);
        // User 10 expenses
        Expense expense27 = new Expense(user10, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense28 = new Expense(user10, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense29 = new Expense(user10, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense27);
        expenses.add(expense28);
        expenses.add(expense29);
        // User 11 expenses
        Expense expense30 = new Expense(user11, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense31 = new Expense(user11, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense32 = new Expense(user11, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense30);
        expenses.add(expense31);
        expenses.add(expense32);
        // Repeat the above for each user up to User 30, adjusting the user ID accordingly

        // User 12 expenses
        Expense expense33 = new Expense(user12, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense34 = new Expense(user12, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense35 = new Expense(user12, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense33);
        expenses.add(expense34);
        expenses.add(expense35);
        // User 13 expenses
        Expense expense36 = new Expense(user13, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense37 = new Expense(user13, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense38 = new Expense(user13, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense36);
        expenses.add(expense37);
        expenses.add(expense38);
     // User 14 expenses
        Expense expense39 = new Expense(user14, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense40 = new Expense(user14, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense41 = new Expense(user14, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense39);
        expenses.add(expense40);
        expenses.add(expense41);

        // User 15 expenses
        Expense expense42 = new Expense(user15, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense43 = new Expense(user15, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense44 = new Expense(user15, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense42);
        expenses.add(expense43);
        expenses.add(expense44);
        // User 16 expenses
        Expense expense45 = new Expense(user16, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense46 = new Expense(user16, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense47 = new Expense(user16, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense45);
        expenses.add(expense46);
        expenses.add(expense47);
     // User 17 expenses
        Expense expense48 = new Expense(user17, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense49 = new Expense(user17, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense50 = new Expense(user17, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense48);
        expenses.add(expense49);
        expenses.add(expense50);
        // Repeat the above for each user up to User 30, adjusting the user ID accordingly

        // User 18 expenses
        Expense expense51 = new Expense(user18, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense52 = new Expense(user18, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense53 = new Expense(user18, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense51);
        expenses.add(expense52);
        expenses.add(expense53);
        // User 19 expenses
        Expense expense54 = new Expense(user19, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense55 = new Expense(user19, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense56 = new Expense(user19, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense54);
        expenses.add(expense55);
        expenses.add(expense56);
     // User 20 expenses
        Expense expense57 = new Expense(user20, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense58 = new Expense(user20, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense59 = new Expense(user20, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense57);
        expenses.add(expense58);
        expenses.add(expense59);
        // Repeat the above for each user up to User 30, adjusting the user ID accordingly

        // User 21 expenses
        Expense expense60 = new Expense(user21, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense61 = new Expense(user21, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense62 = new Expense(user21, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense60);
        expenses.add(expense61);
        expenses.add(expense62);
        // User 22 expenses
        Expense expense63 = new Expense(user22, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense64 = new Expense(user22, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense65 = new Expense(user22, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense63);
        expenses.add(expense64);
        expenses.add(expense65);
     // User 23 expenses
        Expense expense66 = new Expense(user23, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense67 = new Expense(user23, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense68 = new Expense(user23, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense66);
        expenses.add(expense67);
        expenses.add(expense68);
        // Repeat the above for each user up to User 30, adjusting the user ID accordingly

        // User 24 expenses
        Expense expense69 = new Expense(user24, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense70 = new Expense(user24, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense71 = new Expense(user24, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense69);
        expenses.add(expense70);
        expenses.add(expense71);
        // User 25 expenses
        Expense expense72 = new Expense(user25, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense73 = new Expense(user25, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense74 = new Expense(user25, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense72);
        expenses.add(expense73);
        expenses.add(expense74);
        // User 26 expenses
        Expense expense75 = new Expense(user26, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense76 = new Expense(user26, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense77 = new Expense(user26, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense75);
        expenses.add(expense76);
        expenses.add(expense77);
        // Repeat the above for each user up to User 30, adjusting the user ID accordingly

        // User 27 expenses
        Expense expense78 = new Expense(user27, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense79 = new Expense(user27, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense80 = new Expense(user27, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense78);
        expenses.add(expense79);
        expenses.add(expense80);
        // User 28 expenses
        Expense expense81 = new Expense(user28, "Groceries", 55.00, parseDate("2024-04-01"));
        Expense expense82 = new Expense(user28, "Dining Out", 20.00, parseDate("2024-04-02"));
        Expense expense83 = new Expense(user28, "Transportation", 25.00, parseDate("2024-04-03"));
        expenses.add(expense81);
        expenses.add(expense82);
        expenses.add(expense83);
        // User 29 expenses
        Expense expense84 = new Expense(user29, "Groceries", 60.00, parseDate("2024-04-01"));
        Expense expense85 = new Expense(user29, "Dining Out", 35.00, parseDate("2024-04-02"));
        Expense expense86 = new Expense(user29, "Entertainment", 45.00, parseDate("2024-04-03"));
        expenses.add(expense84);
        expenses.add(expense85);
        expenses.add(expense86);
        // User 30 expenses
        Expense expense87 = new Expense(user30, "Transportation", 30.00, parseDate("2024-04-01"));
        Expense expense88 = new Expense(user30, "Utilities", 40.00, parseDate("2024-04-02"));
        Expense expense89 = new Expense(user30, "Healthcare", 55.00, parseDate("2024-04-03"));
        expenses.add(expense87);
        expenses.add(expense88);
        expenses.add(expense89);
        
        expenseRepo.saveAll(expenses);
	}
	private Date parseDate(String dateString) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.parse(dateString);
    }

}
