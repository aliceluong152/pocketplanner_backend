package fdm.group.com.SpringPocketPlanner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.BudgetService;

@RestController
@RequestMapping("budgets")
public class BudgetController {
	BudgetService budgetService;
	
	@Autowired
	public BudgetController(BudgetService budgetService) {
		this.budgetService = budgetService;
	}
	//findAll
	@GetMapping
	public List<Budget>getAllBudgets(){
		return budgetService.findAllBudgets();
	}
	
	//findby Id of Budget 
	@GetMapping("/{id}")
	public Budget getBudgetById(@PathVariable long id) {
		return budgetService.findBudgetById(id);
	}
	
	@PostMapping("/add")
	public void addBudget(@RequestBody Budget budget) {
		budgetService.addBudget(budget);
	}
//	find by cate
	@GetMapping("/category/{category}")
	public List<Budget> getExpensesByCategory(@PathVariable String category) {
	    return budgetService.findByCategory(category);
	}
	@GetMapping("/search")
	public List<Budget>getBySearch(@RequestParam String category){
		return budgetService.findBySearch(category);
	}
	
	@PutMapping("/update")
	public void updateBudget(@RequestBody Budget updatedBudget) {
		budgetService.updateBudget(updatedBudget);
	}
	@DeleteMapping("/{id}")
	public void deleteBudgetById(@PathVariable long id) {
		budgetService.deleteById(id);
	}
	
	//find by User id and category
	@GetMapping("/user")
    public Budget getBudgetByUserAndCategory(@RequestParam long id, @RequestParam String category) {
        return budgetService.findBudgetByUserAndCategory(new User(id), category);
    }
}
