package fdm.group.com.SpringPocketPlanner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import fdm.group.com.SpringPocketPlanner.model.Expense;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.ExpenseService;

@RestController
@RequestMapping("expenses")
public class ExpenseController {
	
	ExpenseService expenseService;
	
	@Autowired
	public ExpenseController(ExpenseService expenseService) {
		this.expenseService = expenseService;
	}
	
	//get all expense
	@GetMapping
	public List<Expense>getAllExpenses(){
		return expenseService.findAllExpenses();
	}
	//find by Id 
	@GetMapping("/{id}")
	public Expense getExpenseById(@PathVariable long id) {
		return expenseService.findExpenseById(id);
	}
	//find by category
	@GetMapping("/category/{category}")
	public List<Expense> getExpensesByCategory(@PathVariable String category) {
	    return expenseService.findByCategory(category);
	}
	//register 
	@PostMapping("/add")
	public void addExpense(@RequestBody Expense expense) {
		expenseService.addExpense(expense);
	}
	//update
	@PutMapping("/update")
	public void updateExpense(@RequestBody Expense updatedExpense) {
		expenseService.updateExpense(updatedExpense);
	}
	//delete
	@DeleteMapping("/{id}")
	public void deleteExpenseById(@PathVariable long id) {
		expenseService.deleteById(id);
	}
	@GetMapping("/user")
    public Expense getExpenseByUserAndCategory(@RequestParam long id, @RequestParam String category) {
        return expenseService.findExpenseByUserAndCategory(new User(id), category);
    }
}
