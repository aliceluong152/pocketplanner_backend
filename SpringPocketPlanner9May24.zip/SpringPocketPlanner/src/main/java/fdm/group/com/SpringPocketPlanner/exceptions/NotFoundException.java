package fdm.group.com.SpringPocketPlanner.exceptions;

public class NotFoundException extends RuntimeException{
	public NotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
