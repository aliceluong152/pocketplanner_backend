package fdm.group.com.SpringPocketPlanner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import fdm.group.com.SpringPocketPlanner.dal.ExpenseRespository;
import fdm.group.com.SpringPocketPlanner.exceptions.ConflictException;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.Expense;
import fdm.group.com.SpringPocketPlanner.model.User;

@Service
public class ExpenseService {
	
	ExpenseRespository expenseRepo;
	public Object findAllExpenses;
	
	@Autowired
	public ExpenseService(ExpenseRespository expenseRepo) {
		
		this.expenseRepo = expenseRepo;
	}
	//find all
	public List<Expense> findAllExpenses() {
		return expenseRepo.findAll();
	}
	//find by category
	public List<Expense> findByCategory(String category) {
	    List<Expense> expenses = expenseRepo.findByCategory(category);
	    if (expenses.isEmpty()) {
	        throw new NotFoundException("Could not find expenses with category " + category);
	    }
	    return expenses;
	}
	//findbyID
	public Expense findExpenseById(long id) {
		return expenseRepo.findById(id).orElseThrow(()->new NotFoundException("Could not find expense with Id "+ id));
	}
	//register
	public void addExpense(Expense expense) {
		if(expenseRepo.existsByCategory(expense.getCategory())) {
			throw new ConflictException("Expense with category " + expense.getCategory()+" already exists.Change your category");
		}else {
			expenseRepo.save(expense);
			System.out.println("NEW EXPENSE ADDED: "+expense.getCategory());
		}
	}
	//update
	public void updateExpense(Expense updatedExpense) {
		expenseRepo.save(updatedExpense);
	}
	//
	public void deleteById(long id) {
		expenseRepo.deleteById(id);
		if (expenseRepo.existsById(id)) {
			throw new RuntimeException("delete failed: budget with user "+id+ "could not be deleted");
		}else {
			System.out.println("budget with Id " +id+" was deleted");
		}
		
	}
	//find by user id and category
		public Expense findExpenseByUserAndCategory(User user, String category) {
			return expenseRepo.findByUserAndCategory(user, category).orElseThrow(()-> new NotFoundException("Could not find budget with ID " +user));
		}
	
	
	
}
