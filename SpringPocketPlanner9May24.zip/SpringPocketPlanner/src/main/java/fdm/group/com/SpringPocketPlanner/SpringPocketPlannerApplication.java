package fdm.group.com.SpringPocketPlanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import fdm.group.com.SpringPocketPlanner.security.RsaKeyProperties;

@SpringBootApplication
@EnableConfigurationProperties(RsaKeyProperties.class)	
public class SpringPocketPlannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPocketPlannerApplication.class, args);
	}

}
