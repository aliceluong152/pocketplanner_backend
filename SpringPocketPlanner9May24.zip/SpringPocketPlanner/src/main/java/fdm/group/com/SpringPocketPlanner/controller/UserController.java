package fdm.group.com.SpringPocketPlanner.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.UserService;

@RestController
@RequestMapping("users")
@CrossOrigin(origins = "http://localhost:5173")
public class UserController {
	
	UserService userService;
	
	@Autowired
	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	@GetMapping("/me")
	public User getCurrentlyLoggedInUser(Authentication auth) {
		return userService.findUserByUsername(auth.getName());
	}
	//findAll
	@GetMapping
	public List<User>getAllUsers(){
		return userService.findAllUsers();
	}
	//register
	@PostMapping("/register")
	public void registerUser(@RequestBody User user) {
		userService.registerUserByUsernameAndEmail(user);
	}
	//findbyID
	@GetMapping("/{id}")
	public User getUserById(@PathVariable Long id) {
		return userService.findUserById(id);
	}
	//findbyUsername
	@GetMapping("/username/{username}")
	public User getUserByUsername(@PathVariable String username) {
		return userService.findUserByUsername(username);
	}
	//search
	@GetMapping("/search")
	public List<User>getBySearch(@RequestParam String username){
		return userService.findBySearch(username);
	}
	//update
	@PutMapping("/update")
	public void updateUser(@RequestBody User updatedUser) {
		userService.updateUser(updatedUser);
	}
	//delete
	@DeleteMapping("/{id}")
	public void deleteUserById(@PathVariable long id) {
		userService.deleteById(id);
	}
	//log in
//	@GetMapping("/login")
//	public String login(@RequestParam(name = "username") String username, @RequestParam(name = "password") String password) {
//		return userService.login(username, password);
//	}
//	
//	@PostMapping("/login")
//    public ResponseEntity<String> login(@RequestBody Map<String, String> credentials) {
//        String username = credentials.get("username");
//        String password = credentials.get("password");
//        String result = userService.login(username, password);
//        return ResponseEntity.ok(result);
//    }
	
	
}
