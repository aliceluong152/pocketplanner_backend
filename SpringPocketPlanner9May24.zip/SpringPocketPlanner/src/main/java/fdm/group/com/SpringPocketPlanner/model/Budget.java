package fdm.group.com.SpringPocketPlanner.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name="budgets")
public class Budget {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "budget_limit", nullable = false)
    private Double limit;

    @Column(name = "month", nullable = false)
    private String month;

    // Constructors
    public Budget() {
    }

    public Budget(User user, String category, Double limit, String month) {
        this.user = user;
        this.category = category;
        this.limit = limit;
        this.month = month;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getLimit() {
        return limit;
    }

    public void setLimit(Double limit) {
        this.limit = limit;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

	@Override
	public String toString() {
		return "Budget [id=" + id + ", user=" + user + ", category=" + category + ", limit=" + limit + ", month="
				+ month + "]";
	}
	
	
}
