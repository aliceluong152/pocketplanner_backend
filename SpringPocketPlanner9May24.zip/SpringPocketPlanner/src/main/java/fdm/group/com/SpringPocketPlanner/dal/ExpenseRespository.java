package fdm.group.com.SpringPocketPlanner.dal;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fdm.group.com.SpringPocketPlanner.model.Expense;
import fdm.group.com.SpringPocketPlanner.model.User;
@Repository
public interface ExpenseRespository extends JpaRepository<Expense, Long>{

	List<Expense> findByCategory(String category);

	void deleteByUser(User user);
	
	boolean existsByCategory(String category);

	Optional<Expense> findByUserAndCategory(User user, String category);
	
}
