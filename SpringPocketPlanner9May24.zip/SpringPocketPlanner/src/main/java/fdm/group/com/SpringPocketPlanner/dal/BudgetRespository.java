package fdm.group.com.SpringPocketPlanner.dal;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.User;
@Repository
public interface BudgetRespository extends JpaRepository<Budget, Long>{

//	boolean existsByUser(User user);

	Optional<Budget> findByUser(User user);
	
	List<Budget> findByCategory(String category);
	
	boolean existsByCategory(String category);
	
	@Query("select b from Budget b where upper(b.category) like concat('%', :input, '%')")
	List<Budget> findByPartialMatch(@Param("input") String search);

	void deleteByUser(User user);
	 
	Optional<Budget> findByUserAndCategory(User user, String category);
	
}
