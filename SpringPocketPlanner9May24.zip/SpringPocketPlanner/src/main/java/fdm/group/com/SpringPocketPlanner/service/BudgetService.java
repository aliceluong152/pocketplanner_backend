package fdm.group.com.SpringPocketPlanner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import fdm.group.com.SpringPocketPlanner.dal.BudgetRespository;
import fdm.group.com.SpringPocketPlanner.exceptions.ConflictException;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.User;

@Service
public class BudgetService {
	BudgetRespository budgetRepo;
	
	@Autowired
	public BudgetService(BudgetRespository budgetRespository) {
		this.budgetRepo = budgetRespository;
	}

	public List<Budget> findAllBudgets() {
		return budgetRepo.findAll();
	}

	//find by Id of budget 
	public Budget findBudgetById(long id) {
		return budgetRepo.findById(id).orElseThrow(()-> new NotFoundException("Could not find budget with ID " +id));
	}
	
	//register
	public void addBudget(Budget budget) {
		if (budgetRepo.existsByCategory(budget.getCategory())){
			throw new ConflictException("Budget with category "+budget.getCategory()+" already exists. Change your category");
		}else {
			budgetRepo.save(budget);
			System.out.println("NEW CATEGORY ADDEDED: "+budget.getCategory());
		}
		
	}
	//find all
	public void saveAll(List<Budget>budgets) {
		for (Budget budget: budgets) {
			addBudget(budget);
		}
	}
	//findbyCate
	public List<Budget> findByCategory(String category) {
	    List<Budget> budgets = budgetRepo.findByCategory(category);
	    if (budgets.isEmpty()) {
	        throw new NotFoundException("Could not find budget with category " + category);
	    }
	    return budgets;
	}
	//search
	public List<Budget> findBySearch(String search) {
		
		return budgetRepo.findByPartialMatch(search);
	}
	//update
	public void updateBudget(Budget updatedBudget) {
		budgetRepo.save(updatedBudget);
		
	}
	
	//delete
	public void deleteById(long id) {
		budgetRepo.deleteById(id);
		if (budgetRepo.existsById(id)) {
			throw new RuntimeException("delete failed: budget with id "+id+ "could not be deleted");
		}else {
			System.out.println("budget with id "+id+" was deleted");
		}
	}
	//find by user id and category
	public Budget findBudgetByUserAndCategory(User user, String category) {
		return budgetRepo.findByUserAndCategory(user, category).orElseThrow(()-> new NotFoundException("Could not find budget with ID " +user));
	}

	
	
}
