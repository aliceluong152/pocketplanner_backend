package fdm.group.com.SpringPocketPlanner.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


import fdm.group.com.SpringPocketPlanner.dal.UserRespository;
import fdm.group.com.SpringPocketPlanner.model.User;


@Service
public class AuthUserService implements org.springframework.security.core.userdetails.UserDetailsService{
	private UserRespository userRepo;
	
	@Autowired
	public AuthUserService(UserRespository userRepo) {
		super();
		this.userRepo = userRepo;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = this.userRepo.findByUsername(username).orElseThrow(
				()-> new UsernameNotFoundException(username));
		return new AuthUser(user);
	}

}
