package fdm.group.com.SpringPocketPlanner.service;

import java.util.List;

import org.antlr.v4.runtime.atn.SemanticContext.AND;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import fdm.group.com.SpringPocketPlanner.dal.UserRespository;
import fdm.group.com.SpringPocketPlanner.exceptions.ConflictException;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.User;

@Service
public class UserService {
	
	UserRespository userRepo;
	PasswordEncoder encoder;
	
	@Autowired
	public UserService(UserRespository userRepo, PasswordEncoder encoder) {
		super();
		this.userRepo = userRepo;
		this.encoder = encoder;
	}
//	//register (username)
//	public void registerUser(User user) {
//		if(userRepo.existsByUsername(user.getUsername())) {
//			throw new ConflictException("User with username "+ user.getUsername()+"already exists. Change your username");
//		}
//		else {
//			String encodedPassword = encoder.encode(user.getPassword());
//			user.setPassword(encodedPassword);
//			userRepo.save(user);
//			System.out.println("NEW USER ADDED: "+user.getUsername());
//		}
//	}
	public void registerUserByUsernameAndEmail(User user) {
		if(userRepo.existsByUsername(user.getUsername())) {
			throw new ConflictException("User with username "+ user.getUsername() +"already exists. Change your username");
		}else if (userRepo.existsByEmail(user.getEmail()))
			throw new ConflictException("User with email "+ user.getEmail() +"already exists. Change your email");
		else {
			String encodedPassword = encoder.encode(user.getPassword());
			user.setPassword(encodedPassword);
			userRepo.save(user);
			System.out.println("NEW USER ADDED: "+user.getUsername());
		}
	}
	//get allUsers
	public List<User>findAllUsers(){
		return userRepo.findAll();
	}
	
	//saveAll
	public void saveAll(List<User>users) {
			for (User user: users) {
				registerUserByUsernameAndEmail(user);
			}
	}
	
	//findbyID
	public User findUserById(long id) {
		return userRepo.findById(id).orElseThrow(()-> new NotFoundException("Could not find user with ID " +id));
	}
	
	//findbyName
	public User findUserByUsername(String username) {
		return userRepo.findByUsername(username).orElseThrow(()-> new NotFoundException("Could not find user with username " + username));
	}
	
	//search
	public List<User> findBySearch(String search) {
		
		return userRepo.findByPartialMatch(search);
	}
	
	//update
	public void updateUser(User updatedUser) {
		userRepo.save(updatedUser);
	}
	//delete
	public void deleteById(long id) {
		userRepo.deleteById(id);
		if(userRepo.existsById(id)) {
			throw new RuntimeException("Delete failed: User with ID " +id+" could not be deleted");
		}else {
			System.out.println("User with ID "+id+" was deleted");
		}
	}
//	//log in 
//	public String login(String username, String password) {
//		if("admin".equals(username) && "admin".equals(password)) {
//			return "admin";
//		}else if(userRepo.existsByUsernameAndPassword(username, password)){
//			return "user";
//		}
//		return "invalid";
//	}
}
