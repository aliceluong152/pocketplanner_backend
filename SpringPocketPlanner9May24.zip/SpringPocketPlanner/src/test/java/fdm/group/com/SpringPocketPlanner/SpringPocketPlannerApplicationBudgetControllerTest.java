package fdm.group.com.SpringPocketPlanner;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import fdm.group.com.SpringPocketPlanner.controller.BudgetController;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.BudgetService;
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SpringPocketPlannerApplicationBudgetControllerTest {
	@Mock
	BudgetService mockBudgetService;
	
	BudgetController budgetController;
	@BeforeEach
	void setUp() throws Exception {
		budgetController = new BudgetController(mockBudgetService);
	}
	//get all
	 @Test
	 void getAllBudgets_ReturnsAllBudgets() {
	    List<Budget> expectedBudgets = Arrays.asList(new Budget(), new Budget());
	    when(mockBudgetService.findAllBudgets()).thenReturn(expectedBudgets);
	    List<Budget> result = budgetController.getAllBudgets();
	    assertEquals(expectedBudgets, result);
	    verify(mockBudgetService, times(1)).findAllBudgets();
	    }
	 //get budget by id
	 @Test
	    void getBudgetById_ReturnsBudget() {
	        long id = 1L;
	        Budget expectedBudget = new Budget();
	        when(mockBudgetService.findBudgetById(id)).thenReturn(expectedBudget);
	        Budget result = budgetController.getBudgetById(id);
	        assertEquals(expectedBudget, result);
	        verify(mockBudgetService, times(1)).findBudgetById(id);
	 }
	 //add budget
	 @Test
	    void addBudget_SavesBudget() {
	        Budget newBudget = new Budget();
	        doNothing().when(mockBudgetService).addBudget(any(Budget.class));
	        assertDoesNotThrow(() -> budgetController.addBudget(newBudget));
	        verify(mockBudgetService, times(1)).addBudget(newBudget);
	    }
	 //find by category
	 @Test
	    void getExpensesByCategory_ReturnsBudgets() {
	        String category = "Food";
	        List<Budget> expectedBudgets = Arrays.asList(new Budget(), new Budget());
	        when(mockBudgetService.findByCategory(category)).thenReturn(expectedBudgets);
	        List<Budget> result = budgetController.getExpensesByCategory(category);
	        assertEquals(expectedBudgets, result);
	        verify(mockBudgetService, times(1)).findByCategory(category);
	 }
	 //update
	 @Test
	    void updateBudget_UpdatesBudget() {
	        Budget updatedBudget = new Budget();
	        doNothing().when(mockBudgetService).updateBudget(any(Budget.class));
	        assertDoesNotThrow(() -> budgetController.updateBudget(updatedBudget));
	        verify(mockBudgetService, times(1)).updateBudget(updatedBudget);
	    }
	 //delete
	 @Test
	    void deleteBudgetById_DeletesBudget() {
	        long id = 1L;
	        doNothing().when(mockBudgetService).deleteById(id);
	        assertDoesNotThrow(() -> budgetController.deleteBudgetById(id));
	        verify(mockBudgetService, times(1)).deleteById(id);
	    }
	 //get budget by user and category
	 @Test
	 void findBudgetByUserAndCategory_Found() {
	        User user = new User();  
	        user.setId(1L);  
	        String category = "Health";

	        Budget expectedBudget = new Budget();  
	        when(mockBudgetService.findBudgetByUserAndCategory(user, category)).thenReturn(expectedBudget);

	        Budget result = mockBudgetService.findBudgetByUserAndCategory(user, category);
	        assertEquals(expectedBudget, result);
	        verify(mockBudgetService, times(1)).findBudgetByUserAndCategory(any(User.class), eq(category));
	 	}
	 @Test
	    void findBudgetByUserAndCategory_NotFound_ThrowsNotFoundException() {
	        User user = new User();
	        user.setId(2L);
	        String category = "Education";	       
	        when(mockBudgetService.findBudgetByUserAndCategory(user, category)).thenThrow(new NotFoundException("Could not find budget with ID " + user.getId()));
	        Exception exception = assertThrows(NotFoundException.class, 
	            () -> mockBudgetService.findBudgetByUserAndCategory(user, category));
	        String expectedMessage = "Could not find budget with ID " + user.getId();
	        String actualMessage = exception.getMessage();
	        assertTrue(actualMessage.contains(expectedMessage));
	 }
}
