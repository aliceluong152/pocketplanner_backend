package fdm.group.com.SpringPocketPlanner;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import fdm.group.com.SpringPocketPlanner.controller.ExpenseController;
import fdm.group.com.SpringPocketPlanner.dal.ExpenseRespository;
import fdm.group.com.SpringPocketPlanner.exceptions.ConflictException;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.Expense;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.ExpenseService;
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SpringPocketPlannerApplicationExpenseServiceTests {
	
	@Mock
	ExpenseRespository mockExpenseRepo;
	
	ExpenseService expenseService;
	@BeforeEach
	void setUp() throws Exception {
		expenseService = new ExpenseService(mockExpenseRepo);
	}

	@Test
    void findAllExpenses_ReturnsAllExpenses() {
        List<Expense> expectedExpenses = Arrays.asList(new Expense(), new Expense());
        when(mockExpenseRepo.findAll()).thenReturn(expectedExpenses);
        List<Expense> actualExpenses = expenseService.findAllExpenses();
        assertEquals(expectedExpenses, actualExpenses);
    }
	 @Test
	    void findByCategory_ThrowsNotFoundExceptionWhenNoExpensesFound() {
	        when(mockExpenseRepo.findByCategory("Travel")).thenReturn(Arrays.asList());

	        Exception exception = assertThrows(NotFoundException.class, () -> expenseService.findByCategory("Travel"));
	        assertEquals("Could not find expenses with category Travel", exception.getMessage());
	    }

	 @Test
	    void findByCategory_ReturnsExpenses() {
	        List<Expense> expectedExpenses = Arrays.asList(new Expense());
	        when(mockExpenseRepo.findByCategory("Food")).thenReturn(expectedExpenses);

	        List<Expense> actualExpenses = expenseService.findByCategory("Food");
	        assertEquals(expectedExpenses, actualExpenses);
	    }
    @Test
    void findExpenseById_ThrowsNotFoundExceptionWhenNotFound() {
        long id = 1L;
        when(mockExpenseRepo.findById(id)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> expenseService.findExpenseById(id));
    }
    @Test
    void findExpenseById_ReturnsExpense() {
        long id = 1L;
        Expense expectedExpense = new Expense();
        when(mockExpenseRepo.findById(id)).thenReturn(Optional.of(expectedExpense));

        Expense actualExpense = expenseService.findExpenseById(id);
        assertEquals(expectedExpense, actualExpense);
    }
    @Test
    void addExpense_ThrowsConflictExceptionWhenCategoryExists() {
        Expense expense = new Expense();
        expense.setCategory("Travel");
        when(mockExpenseRepo.existsByCategory("Travel")).thenReturn(true);

        assertThrows(ConflictException.class, () -> expenseService.addExpense(expense));
    }

    
    @Test
    void addExpense_SavesExpenseSuccessfully() {
        Expense expense = new Expense();
        expense.setCategory("Education");
        when(mockExpenseRepo.existsByCategory("Education")).thenReturn(false);
        when(mockExpenseRepo.save(expense)).thenReturn(expense);  // Assuming save returns the saved Expense

        assertDoesNotThrow(() -> expenseService.addExpense(expense));
        verify(mockExpenseRepo).save(expense);
    }
    @Test
    void deleteExpenseById_DeletesExpense() {
        long id = 1L;
        when(mockExpenseRepo.existsById(id)).thenReturn(false);

        assertDoesNotThrow(() -> expenseService.deleteById(id));
        verify(mockExpenseRepo).deleteById(id);
    }
    @Test
    void updateExpense_SavesUpdatedExpense() {
        Expense updatedExpense = new Expense();
        when(mockExpenseRepo.save(updatedExpense)).thenReturn(updatedExpense);  // Correct mock setup if save() returns Expense

        assertDoesNotThrow(() -> expenseService.updateExpense(updatedExpense));
        verify(mockExpenseRepo).save(updatedExpense);
    }
    @Test
    void findExpenseByUserAndCategory_ReturnsExpense() {
        User user = new User();
        user.setId(1L); 
        String category = "Travel";

        Expense expectedExpense = new Expense();
        when(mockExpenseRepo.findByUserAndCategory(user, category)).thenReturn(Optional.of(expectedExpense));

        Expense actualExpense = expenseService.findExpenseByUserAndCategory(user, category);
        assertEquals(expectedExpense, actualExpense, "The returned expense should match the expected one.");
    }

    @Test
    void findExpenseByUserAndCategory_ThrowsNotFoundExceptionWhenNotFound() {
        User user = new User();
        user.setId(2L);
        String category = "Dining";

        when(mockExpenseRepo.findByUserAndCategory(user, category)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> expenseService.findExpenseByUserAndCategory(user, category),
            "Should throw NotFoundException when no expense is found.");
    }
}
