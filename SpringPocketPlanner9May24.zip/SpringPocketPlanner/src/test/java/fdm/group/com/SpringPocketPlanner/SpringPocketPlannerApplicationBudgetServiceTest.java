package fdm.group.com.SpringPocketPlanner;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import fdm.group.com.SpringPocketPlanner.dal.BudgetRespository;
import fdm.group.com.SpringPocketPlanner.exceptions.ConflictException;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.Budget;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.BudgetService;
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SpringPocketPlannerApplicationBudgetServiceTest {
	@Mock
	BudgetRespository mockBudgetRepo;
	BudgetService budgetService;
	@BeforeEach
	void setUp() throws Exception {
		budgetService = new BudgetService(mockBudgetRepo);
	}

	 @Test
	    void findBudgetById_Found() {
	        long id = 1L;
	        Budget budget = new Budget();
	        when(mockBudgetRepo.findById(id)).thenReturn(Optional.of(budget));

	        Budget foundBudget = budgetService.findBudgetById(id);
	        assertEquals(budget, foundBudget);
	    }
	 @Test
	    void findBudgetById_NotFound() {
	        long id = 1L;
	        when(mockBudgetRepo.findById(id)).thenReturn(Optional.empty());

	        Exception exception = assertThrows(NotFoundException.class, () -> budgetService.findBudgetById(id));
	        assertTrue(exception.getMessage().contains("Could not find budget with ID"));
	    }
	 @Test
	    void addBudget_ThrowsConflictWhenCategoryExists() {
	        Budget budget = new Budget();
	        budget.setCategory("Travel");
	        when(mockBudgetRepo.existsByCategory("Travel")).thenReturn(true);

	        Exception exception = assertThrows(ConflictException.class, () -> budgetService.addBudget(budget));
	        assertTrue(exception.getMessage().contains("already exists"));
	    }
	 @Test
	 void addBudget_SavesBudgetWhenCategoryNotExists() {
	     Budget budget = new Budget();
	     budget.setCategory("Education");
	     when(mockBudgetRepo.existsByCategory("Education")).thenReturn(false);
	     when(mockBudgetRepo.save(any(Budget.class))).thenReturn(budget);  // Ensures return value is handled

	     assertDoesNotThrow(() -> budgetService.addBudget(budget));
	     verify(mockBudgetRepo, times(1)).save(any(Budget.class));  // Uses any() to avoid object mismatch issues
	 }

	    @Test
	    void findByCategory_Found() {
	        List<Budget> budgets = Arrays.asList(new Budget(), new Budget());
	        when(mockBudgetRepo.findByCategory("Food")).thenReturn(budgets);

	        List<Budget> foundBudgets = budgetService.findByCategory("Food");
	        assertFalse(foundBudgets.isEmpty());
	        assertEquals(2, foundBudgets.size());
	    }

	    @Test
	    void findByCategory_NotFound() {
	        when(mockBudgetRepo.findByCategory("Luxury")).thenReturn(Arrays.asList());

	        Exception exception = assertThrows(NotFoundException.class, () -> budgetService.findByCategory("Luxury"));
	        assertTrue(exception.getMessage().contains("Could not find budget with category"));
	    }

	    @Test
	    void findBySearch() {
	        List<Budget> budgets = Arrays.asList(new Budget(), new Budget());
	        when(mockBudgetRepo.findByPartialMatch("part")).thenReturn(budgets);

	        List<Budget> foundBudgets = budgetService.findBySearch("part");
	        assertFalse(foundBudgets.isEmpty());
	        assertEquals(2, foundBudgets.size());
	    }

	    @Test
	    void updateBudget() {
	        Budget budget = new Budget();
	        // Assuming save returns the saved entity
	        when(mockBudgetRepo.save(any(Budget.class))).thenReturn(budget);

	        assertDoesNotThrow(() -> budgetService.updateBudget(budget));
	        verify(mockBudgetRepo).save(any(Budget.class));  
	    }
	    @Test
	    void deleteById_DeletesSuccessfully() {
	        long id = 1L;
	        when(mockBudgetRepo.existsById(id)).thenReturn(false);

	        assertDoesNotThrow(() -> budgetService.deleteById(id));
	        verify(mockBudgetRepo).deleteById(id);
	    }

	    @Test
	    void deleteById_FailsToDelete() {
	        long id = 1L;
	        when(mockBudgetRepo.existsById(id)).thenReturn(true);

	        Exception exception = assertThrows(RuntimeException.class, () -> budgetService.deleteById(id));
	        assertTrue(exception.getMessage().contains("could not be deleted"));
	    }
	    @Test
	    void findBudgetByUserAndCategory_Found() {
	        User user = new User();  
	        user.setId(1L);  
	        String category = "Health";

	        Budget expectedBudget = new Budget();  
	        when(mockBudgetRepo.findByUserAndCategory(user, category)).thenReturn(Optional.of(expectedBudget));

	        Budget result = budgetService.findBudgetByUserAndCategory(user, category);
	        assertEquals(expectedBudget, result);
	    }

	    @Test
	    void findBudgetByUserAndCategory_NotFound_ThrowsNotFoundException() {
	        User user = new User();
	        user.setId(2L);
	        String category = "Education";

	        when(mockBudgetRepo.findByUserAndCategory(user, category)).thenReturn(Optional.empty());

	        Exception exception = assertThrows(NotFoundException.class, 
	            () -> budgetService.findBudgetByUserAndCategory(user, category));

	        String expectedMessage = "Could not find budget with ID " + user;
	        String actualMessage = exception.getMessage();
	        assertTrue(actualMessage.contains(expectedMessage));
	    }

}
