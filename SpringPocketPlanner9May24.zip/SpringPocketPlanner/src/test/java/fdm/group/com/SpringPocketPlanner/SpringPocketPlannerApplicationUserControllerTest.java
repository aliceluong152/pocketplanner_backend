package fdm.group.com.SpringPocketPlanner;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import fdm.group.com.SpringPocketPlanner.controller.UserController;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.UserService;
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SpringPocketPlannerApplicationUserControllerTest {
	@Mock
	UserService mockUserService;
	
	UserController userController;
	@BeforeEach
	void setUp() throws Exception {
		userController = new UserController(mockUserService);
	}
//getall
	@Test
    void getAllUsers_ReturnsListOfUsers() {
        List<User> users = new ArrayList<>();
        users.add(new User());
        when(mockUserService.findAllUsers()).thenReturn(users);

        List<User> result = userController.getAllUsers();
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
	}
//register
	 @Test
	    void registerUser_CallsUserService() {
	        User user = new User();
	        MockHttpServletRequest request = new MockHttpServletRequest();
	        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

	        doNothing().when(mockUserService).registerUser(user);
	        assertDoesNotThrow(() -> userController.registerUser(user));
	        verify(mockUserService, times(1)).registerUser(user);
	    }
//getbyId
	 @Test
	    void getUserById_ReturnsUser() {
	        User user = new User();
	        when(mockUserService.findUserById(anyLong())).thenReturn(user);

	        User result = userController.getUserById(1L);
	        assertNotNull(result);
	    }
//getbyUsername
	 @Test
	    void getUserByUsername_ReturnsUserFromService() {	 
	        String username = "testUser";
	        User expectedUser = new User();
	        expectedUser.setUsername(username);
	        expectedUser.setId(1L); // Example ID
	        when(mockUserService.findUserByUsername(username)).thenReturn(expectedUser);
	        User result = userController.getUserByUsername(username);
	        assertEquals(expectedUser, result);
	        verify(mockUserService, times(1)).findUserByUsername(username);
	    }
	 @Test
	    void getUserByUsername_ThrowsNotFoundExceptionWhenUserNotPresent() {
	        String username = "nonexistentUser";
	        when(mockUserService.findUserByUsername(username)).thenThrow(new RuntimeException("User not found"));
	        Exception exception = assertThrows(RuntimeException.class, () -> userController.getUserByUsername(username));
	        assertEquals("User not found", exception.getMessage());
	        verify(mockUserService, times(1)).findUserByUsername(username);
	    }
//delete
	    @Test
	    void deleteUserById_CallsUserService() {
	        doNothing().when(mockUserService).deleteById(anyLong());

	        assertDoesNotThrow(() -> userController.deleteUserById(1L));
	        verify(mockUserService, times(1)).deleteById(1L);
	    }
//search
	    @Test
	    void getBySearch_ReturnsUserList() {
	      
	        List<User> expectedUsers = Arrays.asList(new User(), new User());
	        when(mockUserService.findBySearch("query")).thenReturn(expectedUsers);	   
	        List<User> result = userController.getBySearch("query");	       
	        assertEquals(expectedUsers, result);
	        verify(mockUserService, times(1)).findBySearch("query");
	    }
//login 
	    @Test
	    void login_ReturnsCorrectResponseFromService() {
	        // Setup
	        String username = "user";
	        String password = "password";
	        when(mockUserService.login(username, password)).thenReturn("user");
	        String result = userController.login(username, password);
	        assertEquals("user", result);
	        verify(mockUserService, times(1)).login(username, password);
	    }
	    @Test
	    void login_ReturnsInvalidWhenCredentialsAreIncorrect() {	      
	        String username = "invalidUser";
	        String password = "invalidPass";
	        when(mockUserService.login(username, password)).thenReturn("invalid");	     
	        String result = userController.login(username, password);
	        assertEquals("invalid", result);
	        verify(mockUserService, times(1)).login(username, password);
	    }
	    
}
