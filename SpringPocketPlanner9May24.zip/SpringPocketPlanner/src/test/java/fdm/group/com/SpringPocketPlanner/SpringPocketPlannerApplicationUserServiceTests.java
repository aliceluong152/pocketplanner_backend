package fdm.group.com.SpringPocketPlanner;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import fdm.group.com.SpringPocketPlanner.dal.UserRespository;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.UserService;
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SpringPocketPlannerApplicationUserServiceTests {
	
	@Mock 
	UserRespository mockUserRespository;
	
	UserService userService;
	@BeforeEach
	void setUp() throws Exception {
		userService = new UserService(mockUserRespository);
	}
	//find all 
	 @Test
	    void findAllUsers_ReturnsListOfUsers() {
	        List<User> users = new ArrayList<>();
	        users
	        .add(new User());
	        when(mockUserRespository.findAll()).thenReturn(users);

	        List<User> result = userService.findAllUsers();
	        assertFalse(result.isEmpty());
	        assertEquals(1, result.size());
	    }
	 //findbyID
	 @Test
	    void findUserById_ThrowsNotFoundWhenUserDoesNotExist() {
	        when(mockUserRespository.findById(anyLong())).thenReturn(Optional.empty());

	        Exception exception = assertThrows(NotFoundException.class, () -> userService.findUserById(1L));
	        assertTrue(exception.getMessage().contains("Could not find user with ID"));
	    }
	 
	 @Test
	    void findUserById_ReturnsUserWhenExists() {
	        User user = new User();
	        when(mockUserRespository.findById(anyLong())).thenReturn(Optional.of(user));

	        User foundUser = userService.findUserById(1L);
	        assertNotNull(foundUser);
	    }
	 //register
	 @Test
	 void registerUser_SavesUserWhenNotExists() {
	     User user = new User();
	     user.setUsername("newUser");
	     when(mockUserRespository.existsByUsername("newUser")).thenReturn(false);
	     when(mockUserRespository.save(any(User.class))).thenReturn(user); // Assuming save returns the user

	     assertDoesNotThrow(() -> userService.registerUser(user));
	     verify(mockUserRespository, times(1)).save(user);
	 }	 
	 //delete 
	 @Test
	    void deleteById_DeletesSuccessfully() {
        long userId = 1L;
        when(mockUserRespository.existsById(userId)).thenReturn(false);

        assertDoesNotThrow(() -> userService.deleteById(userId));

        verify(mockUserRespository).deleteById(userId);
        verify(mockUserRespository).existsById(userId);
	    }
	 //update
	 @Test
	    void updateUser_CallsSaveOnRepository() {
	    User updatedUser = new User();
	    updatedUser.setId(1L); 
	    updatedUser.setUsername("updatedUser");
	    updatedUser.setEmail("update@example.com"); 
	
	    // Act
	    userService.updateUser(updatedUser);
	
	    // Assert
	    verify(mockUserRespository, times(1)).save(any(User.class)); 
	    verify(mockUserRespository, times(1)).save(updatedUser); 
    }
	 @Test
	    void login_ReturnsAdminForAdminCredentials() {
	        // Setup
	        String username = "admin";
	        String password = "admin";

	        // Execution & Verification
	        String result = userService.login(username, password);
	        assertEquals("admin", result);
	    }
	 @Test
	    void login_ReturnsUserForValidCredentials() {
	        // Setup
	        String username = "user";
	        String password = "password";
	        when(mockUserRespository.existsByUsernameAndPassword(username, password)).thenReturn(true);

	        // Execution
	        String result = userService.login(username, password);

	        // Verification
	        assertEquals("user", result);
	    }
	 @Test
	    void login_ReturnsInvalidForInvalidCredentials() {
	        // Setup
	        String username = "wrong";
	        String password = "wrong";
	        when(mockUserRespository.existsByUsernameAndPassword(username, password)).thenReturn(false);

	        // Execution
	        String result = userService.login(username, password);

	        // Verification
	        assertEquals("invalid", result);
	    }
}
