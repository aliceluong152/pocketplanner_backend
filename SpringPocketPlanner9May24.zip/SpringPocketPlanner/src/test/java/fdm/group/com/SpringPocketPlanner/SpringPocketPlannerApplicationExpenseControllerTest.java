package fdm.group.com.SpringPocketPlanner;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import fdm.group.com.SpringPocketPlanner.controller.ExpenseController;
import fdm.group.com.SpringPocketPlanner.exceptions.NotFoundException;
import fdm.group.com.SpringPocketPlanner.model.Expense;
import fdm.group.com.SpringPocketPlanner.model.User;
import fdm.group.com.SpringPocketPlanner.service.ExpenseService;
@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SpringPocketPlannerApplicationExpenseControllerTest {
	@Mock
	ExpenseService mockExpenseService;
	
	ExpenseController expenseController;
	@BeforeEach
	void setUp() throws Exception {
		expenseController = new ExpenseController(mockExpenseService);
	}
	
	@Test
    void getAllExpenses_ReturnsListOfExpenses() {
        List<Expense> expectedExpenses = Arrays.asList(new Expense(), new Expense());
        when(mockExpenseService.findAllExpenses()).thenReturn(expectedExpenses);

        List<Expense> expenses = expenseController.getAllExpenses();
        assertEquals(expectedExpenses, expenses);
    }
	@Test
    void getExpenseById_ReturnsExpense() {
        Expense expectedExpense = new Expense();
        long id = 1L;
        when(mockExpenseService.findExpenseById(id)).thenReturn(expectedExpense);

        Expense expense = expenseController.getExpenseById(id);
        assertEquals(expectedExpense, expense);
    }
	 @Test
	    void getExpensesByCategory_ReturnsExpensesList() {
	        String category = "Travel";
	        List<Expense> expectedExpenses = Arrays.asList(new Expense(), new Expense());
	        when(mockExpenseService.findByCategory(category)).thenReturn(expectedExpenses);

	        List<Expense> expenses = expenseController.getExpensesByCategory(category);
	        assertEquals(expectedExpenses, expenses);
	    }
	 @Test
	    void addExpense_CallsAddExpense() {
	        Expense expense = new Expense();
	        doNothing().when(mockExpenseService).addExpense(expense);

	        assertDoesNotThrow(() -> expenseController.addExpense(expense));
	        verify(mockExpenseService).addExpense(expense);
	    }
	 @Test
	    void updateExpense_UpdatesExpense() {
	        Expense updatedExpense = new Expense();
	        doNothing().when(mockExpenseService).updateExpense(updatedExpense);

	        assertDoesNotThrow(() -> expenseController.updateExpense(updatedExpense));
	        verify(mockExpenseService).updateExpense(updatedExpense);
	    }
	 @Test
	    void deleteExpenseById_DeletesExpense() {
	        long id = 1L;
	        doNothing().when(mockExpenseService).deleteById(id);

	        assertDoesNotThrow(() -> expenseController.deleteExpenseById(id));
	        verify(mockExpenseService).deleteById(id);
	    }
	 @Test
	    void findByUserAndCategory_ReturnsExpense() {
	        User user = new User();
	        user.setId(1L); 
	        String category = "Travel";

	        Expense expectedExpense = new Expense();
	        when(mockExpenseService.findExpenseByUserAndCategory(user, category)).thenReturn(expectedExpense);

	        Expense actualExpense = mockExpenseService.findExpenseByUserAndCategory(user, category);
	        assertEquals(expectedExpense, actualExpense, "The returned expense should match the expected one.");
	    }

	 @Test
	 void findByUserAndCategory_ThrowsNotFoundExceptionWhenNotFound() {
	     User user = new User();
	     user.setId(2L);
	     String category = "Dining";
	     String exceptionMessage = "Could not find expense with user " + user.getId() + " and category " + category;
	     when(mockExpenseService.findExpenseByUserAndCategory(user, category)).thenThrow(new NotFoundException(exceptionMessage));     // Test that the exception is thrown with the correct message
	     Exception exception = assertThrows(NotFoundException.class, 
	         () -> mockExpenseService.findExpenseByUserAndCategory(user, category),
	         "Should throw NotFoundException when no expense is found.");
	 }
}
